#!usr/bin/env python
# -*- coding:utf-8 -*-
"""
@author: macbookpro
@file: Question3.py
@time: 2025/02/20
@desc:
"""
import numpy as np
import pandas as pd
import pyomo.environ as pyo
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TkAgg')

# 1. Load dataset
data = pd.read_csv("https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data", header=None)
data.columns = ["sepal_length", "sepal_width", "petal_length", "petal_width", "class"]

# 2. Preprocess data
data['label'] = np.where(data['class'] == 'Iris-setosa', 1, -1)
X = data.iloc[:, :4].values
y = data['label'].astype(int).values

# 3. Define parameters
n_samples, n_features = X.shape
epsilon = 1e-4  # try tolerance values 1e-6, 1e-5, 1e-4, 1e-3
max_iter = 500  # Maximum iterations

# 4. Find an initial feasible solution
def find_initial_feasible_solution(X, y, M):
    model = pyo.ConcreteModel()

    # Decision variables
    model.w = pyo.Var(range(n_features), within=pyo.Reals, bounds=(-M, M))
    model.b = pyo.Var(within=pyo.Reals, bounds=(-M, M))
    model.u = pyo.Var(range(n_features), within=pyo.NonNegativeReals)  # Extra variable u_j

    # Constraints
    model.constraints = pyo.ConstraintList()
    for i in range(n_samples):
        model.constraints.add(y[i] * (sum(model.w[j] * X[i, j] for j in range(n_features)) + model.b) >= 1)

    # Linear objective function: minimize ∑ u_j
    model.objective = pyo.Objective(expr=sum(model.u[j] for j in range(n_features)), sense=pyo.minimize)

    # Constraints: Replace quadratic term w_j^2 -> linear u_j
    for j in range(n_features):
        model.add_component(f"L1_constraint_pos_{j}", pyo.Constraint(expr=model.u[j] >= model.w[j]))
        model.add_component(f"L1_constraint_neg_{j}", pyo.Constraint(expr=model.u[j] >= -model.w[j]))

    solver = pyo.SolverFactory('glpk')
    solver.solve(model)
    w = np.array([pyo.value(model.w[j]) for j in range(n_features)])
    b = pyo.value(model.b)
    return w, b

# 5. Compute the optimization direction
def find_direction(w, b, X, y, M):
    model_d = pyo.ConcreteModel()
    # Decision variables
    model_d.v = pyo.Var(range(n_features), within=pyo.Reals, bounds=(-M, M))
    model_d.b_v = pyo.Var(within=pyo.Reals, bounds=(-M, M))

    # Constraints
    model_d.constraints = pyo.ConstraintList()
    for i in range(n_samples):
        model_d.constraints.add(y[i] * (sum(model_d.v[j] * X[i, j] for j in range(n_features)) + model_d.b_v) >= 1)

    # Objective function
    model_d.objective = pyo.Objective(expr=sum(w[j] * model_d.v[j] for j in range(n_features)), sense=pyo.minimize)
    solver = pyo.SolverFactory('glpk')
    solver.solve(model_d)

    # Extract direction
    v_k = np.array([pyo.value(model_d.v[j]) for j in range(n_features)])
    b_v = pyo.value(model_d.b_v)

    return v_k - w, b_v - b

# 6. Compute step size
def compute_step_size(w, d_w):
    numerator = np.dot(w, d_w)
    denominator = np.dot(d_w, d_w)
    tau = -numerator / denominator if denominator != 0 else 0
    return max(0, min(1, tau))

# 7. Run optimization for different M values
M_values = [1, 5, 10, 50, 100, 500, 1000, 10000]
accuracy_results = []
w_norm_results = []
b_results = []
final_w_values = []
final_b_values = []

for M in M_values:
    print(f"\nRunning optimization for M = {M}")
    w, b = find_initial_feasible_solution(X, y, M)
    for iteration in range(max_iter):
        d_w, d_b = find_direction(w, b, X, y, M)
        tau = compute_step_size(w, d_w)
        w = w + tau * d_w
        b = b + tau * d_b
        if np.linalg.norm(tau * d_w) < epsilon:
            break

    # Compute classification accuracy
    def predict(X, w, b):
        return np.sign(X @ np.array(w) + b)

    y_pred = predict(X, w, b)
    accuracy = np.mean(y_pred == y) * 100
    w_norm = np.linalg.norm(w)
    accuracy_results.append(accuracy)
    w_norm_results.append(w_norm)
    b_results.append(b)
    final_w_values.append(w)
    final_b_values.append(b)
    print(f"M = {M} -> w: {w}, b: {b}")

# 8. select best w and b （M=1000）
best_M_index = M_values.index(1000)
best_w = final_w_values[best_M_index]
best_b = final_b_values[best_M_index]
print("\nBest optimized values (for M = 1000):")
print(f"w = {best_w}")
print(f"b = {best_b}")

# 9. Plot results
plt.figure(figsize=(12, 5))
# Accuracy vs M
plt.subplot(1, 3, 1)
plt.plot(M_values, accuracy_results, marker='o', linestyle='-')
plt.xscale("log")
plt.xlabel("M (Constraint Bound)")
plt.ylabel("Classification Accuracy (%)")
plt.title("Accuracy vs M")
plt.grid(True)

# ||w|| vs M
plt.subplot(1, 3, 2)
plt.plot(M_values, w_norm_results, marker='s', linestyle='-', color='red')
plt.xscale("log")
plt.xlabel("M (Constraint Bound)")
plt.ylabel("||w|| (Magnitude of w)")
plt.title("Norm of w vs M")
plt.grid(True)

# b vs M
plt.subplot(1, 3, 3)
plt.plot(M_values, b_results, marker='^', linestyle='-', color='green')
plt.xscale("log")
plt.xlabel("M (Constraint Bound)")
plt.ylabel("Final b Value")
plt.title("Bias b vs M")
plt.grid(True)
plt.tight_layout()
plt.show()
