#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Group Assignment:
Module Code: IB9E00 Pricing Analytics
School Year: 2024/25
Group 7

"""
#========================================================
# Decision Variables:
#  x[i, j, t]: Number of rental contracts accepted for equipment j with rental duration i in week t.
#  I[j, t]: Inventory level of equipment j in week t.

# Objective Function:
#  Maximise total revenue from rentals over the one year.

# Constraints:
# 1. Inventory constraint: Rentals cannot exceed available stock.
# 2. Demand constraint: Accepted rentals cannot exceed market demand.
# 3. Inventory update constraint: Tracks stock levels over time.

#========================================================

# Import necessary libraries
import numpy as np
import pandas as pd
from pyomo.environ import *

# Load dataset from Excel file
file_name = "Group7_IB9EO0.xlsx"
df = pd.read_excel(file_name, "BuildMax_Rentals_Dataset")

# Extract relevant data from the dataset
df_table = df.iloc[0:52]

# Define rental durations (in days)
Total_rental_duration = {1: 7, 2: 28, 3: 56, 4: 112}

# Create a dictionary for equipment types.
equipment_names = {1: "Excavator", 2: "Cranes", 3: "Bulldozers"}

# Create the range for i, j, t
durations = [1, 2, 3, 4]  
equipments = [1, 2, 3]  
weeks = list(range(1, 53)) 
 
# Create a dictionary different rental durations
durations_weeks = {1: 1, 2: 4, 3: 8, 4: 16} 

# Extract initial inventory.
initial_inventory = {1: df.iloc[0, -6], 2: df.iloc[0, -5], 3: df.iloc[0, -4] }

# Create a dictionary for equipment rental price per day
Price_ijt = {}
for t in weeks:
    for j, eq_names in enumerate(["Excavators", "Cranes", "Bulldozers"], start=1):
        for i, duration in enumerate(["1-week", "4-weeks", "8-weeks", "16-weeks"], start=1):
            Price_ijt[i, j, t] = df_table[f"{eq_names} - {duration} Price per day (£)"][t-1]

# Create a dictionary for demand
Demand_ijt = {}
for t in weeks:
    for j, eq_names in enumerate(["Excavators", "Cranes", "Bulldozers"], start=1):
        for i, duration in enumerate(["1-week", "4-weeks", "8-weeks", "16-weeks"], start=1):
            Demand_ijt[i, j, t] = df_table[f"{eq_names} - {duration} Demand (units)"][t-1]


model = ConcreteModel()

# Decision variables:
model.x = Var(durations, equipments, weeks, domain=NonNegativeIntegers)
model.I = Var(equipments, weeks, domain=NonNegativeIntegers)
model.I_initial = Param(equipments, initialize=initial_inventory)

# Define the objective function (maximise total revenue)
def objective_rule(model):
    return sum(Price_ijt[i, j, t] * model.x[i, j, t] * Total_rental_duration[i]  
               for i in durations for j in equipments for t in weeks)
model.obj = Objective(rule=objective_rule, sense=maximize)

# Constraint 1: Rentals cannot exceed available inventory
def lessthan_inventory(model, j, t):      
    return sum(model.x[i, j, t] for i in durations) <= model.I[j, t]
model.lessthan_inventory_con1 = Constraint(equipments, weeks, rule=lessthan_inventory)

# Constraint 2: Rentals cannot exceed demand
def lessthan_demand(model, i, j, t):
    return model.x[i, j, t] <= Demand_ijt[i, j, t]
model.lessthan_demand_con2 = Constraint(durations, equipments, weeks, rule=lessthan_demand)

# Constraint 3: Inventory update constraint (tracking stock over time)
def inventory_update(model, j, t):
    if t == 1:
        return model.I[j, t] == model.I_initial[j]
    else:
        return (model.I[j, t] == model.I[j, t - 1]  
                + sum((model.x[i, j, t - durations_weeks[i]] if (t - durations_weeks[i]) >= 1 else 0) for i in durations)
                - sum(model.x[i, j, t-1] for i in durations))
model.inventory_update_con3 = Constraint(equipments, weeks, rule=inventory_update)

# Solve the model
solver = SolverFactory('glpk')
results = solver.solve(model)

# Output results
print("\n=== Final Solution ===")
print(f'The optimised total revenue: £{model.obj():,.2f}')

# Compute ROI metrics
Actual_total_revenue = df.iloc[0, -1]
Purchaseprice_excavator = df.iloc[6, -1]
Purchaseprice_cranes = df.iloc[7, -1]
Purchaseprice_bulldozers = df.iloc[8, -1]
Total_cost = (initial_inventory[1] * Purchaseprice_excavator +
              initial_inventory[2] * Purchaseprice_cranes +
              initial_inventory[3] * Purchaseprice_bulldozers)

ROI_Actual = (Actual_total_revenue - Total_cost) / Total_cost * 100
ROI_optimised = (model.obj() - Total_cost) / Total_cost * 100
ROI_improvement = (ROI_optimised - ROI_Actual) / ROI_Actual * 100

print(f"The actual ROI: {ROI_Actual:.2f}%")
print(f"The optimised ROI: {ROI_optimised:.2f}%")
print(f"The improvement of ROI: {ROI_improvement:.2f}%")

# Store results in a DataFrame
df_results = pd.DataFrame(index=weeks)

# Store optimised rental decisions and inventory
for i in durations:
    for j in equipments:
        df_results[f"{equipment_names[j]}-{durations_weeks[i]} weeks Accepted"] = [value(model.x[i, j, t]) for t in weeks]
for j in equipments:
    df_results[f"Inventory of {equipment_names[j]}"] = [value(model.I[j, t]) for t in weeks]

df_results.at[weeks[0], "Total Revenue"] = value(model.obj())
df_results.at[weeks[0], "Actual ROI"] = f"{ROI_Actual:.2f}%"
df_results.at[weeks[0], "Optimised ROI"] = f"{ROI_optimised:.2f}%"
df_results.at[weeks[0], "Improvement of ROI"] = f"{ROI_improvement:.2f}%"

# Save results to an Excel file
excel_path = "Optimised Results.xlsx"
df_results.to_excel(file_name, index=False)
